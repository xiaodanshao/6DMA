function res = log_d(A,B_b)
N = 4;
noise_power = 10^(-5); % Watt
res = real(log2(det(eye(N)+(1/noise_power)*A'*B_b*A)));
end