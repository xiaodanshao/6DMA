function A = get_A_b(q_b,R_b,zk,b,k_m,B,N,lammda)
num_user = size(zk,1);
a = zeros(N,B);
A_bb = zeros(N,num_user);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';

r = get_global_antenna_location(r_local,R_b,q_b);

for user_idx = 1:num_user
    a(:,b) = get_steering_vector(k_m(:,user_idx),r,lammda);
    ge = get_antenna_pattern(k_m(:,user_idx),R_b);
    G_b_k=a(:,b)*ge;
    A_bb(:,user_idx)=G_b_k; 
end
    A_b=A_bb.';
    A =A_b;
end