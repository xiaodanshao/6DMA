function r_b = get_global_antenna_location(r_local,R_b,q_b)

r_b = q_b + R_b' * r_local;

end