function W_s = get_ini_W(q,u,B,N,r_local,zk_tag,transmit_power,lammda)
K_trial =  size(zk_tag,2);

R = zeros(3,3,B);
r = zeros(3,N,B);

for i = 1:K_trial
    num_user = size(zk_tag{i},1);
    W_s{i} = zeros(num_user,num_user,B);
    % W{s,i} = zeros(num_user,num_user,B);
    W_sum=zeros(num_user,num_user);
    for b = 1:B
        q_b = q(3*(b - 1) + 1 : 3*b);
        u_b = u(3*(b - 1) + 1 : 3*b);
        R(:,:,b) = get_rotation_matrix(u_b);
        r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
        
        vv = zeros(num_user,1);
        A_bb = zeros(N,num_user);
        for user_idx = 1:num_user
            k_m = get_k_vector(zk_tag{i}(user_idx,1),zk_tag{i}(user_idx,2),zk_tag{i}(user_idx,3));
            vv(user_idx) = get_attenuation_factor(zk_tag{i}(user_idx,1:3),lammda);
            % a(:,b) = get_steering_vector(k_m,r(:,:,b),lammda);
            a_b = exp(-1i*2*pi/lammda*(k_m'* r(:,:,b))).';
            % g = get_antenna_pattern(k_m,R(:,:,b));        
            local_location = -R(:,:,b) * k_m;
            local_location = (local_location)/vecnorm(local_location);
            theta_prime = acos(local_location(3));
            phi_prime = acos(local_location(1)/(sqrt(local_location(1)^2+local_location(2)^2)));
            a_H_E = -12 * ((phi_prime * 2.769) ^ 2 + ((theta_prime - pi/2 ) * 2.769) ^ 2 );
            a_gpu = 10^((a_H_E)/10);
            g_gpu = 7.943 * sqrt(a_gpu);
            % g_gpu = 7.943 * sqrt(max(10^(-10),a_gpu));
            G_b_k=a_b*g_gpu ;
            A_bb(:,user_idx)=G_b_k; 
        end
            A_b=A_bb.';
            sigm=diag(vv);
            P=transmit_power*ones(num_user,1);
            Lam=diag(P);
            W=Lam^(0.5)*sigm'*A_b;
            W_sum=W_sum+W*W';
            % W*W'
            W_s{i}(:,:,b) = W*W';
    end
end
end