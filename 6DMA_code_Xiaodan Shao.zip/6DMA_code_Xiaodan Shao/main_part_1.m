%% Xiaodan Shao, Please cite the article
% [1] X. Shao, Q. Jiang, and R. Zhang. 6D movable antenna based on user distribution: 
% Modeling and optimization. arXiv preprint arXiv:2403.08123, 2024.
%[2] X. Shao, R. Zhang, Q. Jiang, and R.Schober. 6D movable antenna enhanced wireless network 
% via discrete position and rotation optimization. arXiv preprint arXiv:2403.17122, 2024.

clear;
%% parameter set-up
N_total = 64;
N_candidate = [4 16];
user_number = [10 20 30 40 50];
transmit_power = [20 40 60 80 100 120] * 10^(-3);
region_size = 0.6;

B_candidate = N_total./ N_candidate;
lammda = 0.125;
noise_power = 10^(-8);
r_local{1} =   lammda * [0,      1/4,        1/4;
                         0,      -1/4,       1/4;
                         0,      -1/4,       -1/4;
                         0,      1/4,        -1/4]' ;

r_local{2}  =   lammda * [0,        -3/4,       3/4;
                          0         -1/4,       3/4;
                          0,         1/4,       3/4;
                          0,         3/4,       3/4;
                          0,        -3/4,       1/4;
                          0         -1/4,       1/4;
                          0,         1/4,       1/4;
                          0,         3/4,       1/4;
                          0,        -3/4,       -1/4;
                          0         -1/4,       -1/4;
                          0,         1/4,       -1/4;
                          0,         3/4,       -1/4;
                          0,        -3/4,       -3/4;
                          0         -1/4,       -3/4;
                          0,         1/4,       -3/4;
                          0,         3/4,       -3/4;]';

iter = 30;

%% picture 1 convergence analysis

zk_tag = load("user_locations\density_zk_2.mat");
AO_sample_num = 10;
zk_tag = zk_tag.zk;
power_idx = 2;
for N_idx = 1:2   
    % random initialization
    best_val_Fib = -inf;
    tmp_data = zeros(AO_sample_num,iter);
    for i = 1:AO_sample_num
        [q_Fib, u_Fib] = gene_candidate_position_Fibonacci(region_size,B_candidate(N_idx));
        [initial_val_Fib,value_per_iter_Fib,q_opt_Fib,u_opt_Fib] = ...
                CSM_AO_u(q_Fib,u_Fib,N_candidate(N_idx),B_candidate(N_idx),transmit_power(power_idx),noise_power,lammda,r_local{N_idx},iter,zk_tag,region_size);
        tmp_data(i,:) = value_per_iter_Fib;
        
    end
    % result.value_per_iter_Fib{N_idx} = mean(tmp_data,1);

    if (value_per_iter_Fib(end) > best_val_Fib)
        best_val_Fib = value_per_iter_Fib(end);
        result.q_initial_AO_user_Fib{N_idx} = q_Fib;
        result.u_initial_AO_user_Fib{N_idx} = u_Fib;
        result.initial_val_AO_Fib{N_idx} = initial_val_Fib;
        result.value_per_iter_Fib{N_idx} = value_per_iter_Fib;
        result.q_opt_AO_user_Fib{N_idx} = q_opt_Fib;
        result.u_opt_AO_user_Fib{N_idx} = u_opt_Fib;
    end

end

save("result_19_Feb_convergence.mat","result");

