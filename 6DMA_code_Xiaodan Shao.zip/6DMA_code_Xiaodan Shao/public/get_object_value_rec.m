function [E_C] = get_object_value_rec(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W)
K_trial = size(zk_tag,2);
E_C = 0;

q_b = q(3*(b - 1) + 1 : 3*b);
u_b = u(3*(b - 1) + 1 : 3*b);
R_b = get_rotation_matrix(u_b);
r_b = get_global_antenna_location(r_local,R_b,q_b);

E_C_s = zeros(K_trial,1);
for i=1:K_trial
    [E_C_s(i)] = get_capacity_rec(N,R_b,r_b,transmit_power,noise_power,zk_tag{i},lammda,b,W{i}); 
end

E_C = E_C + sum(E_C_s,"all")/K_trial;
E_C = real(E_C);



    function C_q_u_zk_new = get_capacity_rec(N,R_b,r_b,transmit_power,noise_power,zk,lammda,b,W_s)
    num_user = size(zk,1);
    W_sum=zeros(num_user,num_user);
    vv = zeros(num_user,1);
    A_bb = zeros(N,num_user);
    for user_idx = 1:num_user
        k_m = get_k_vector(zk(user_idx,1),zk(user_idx,2),zk(user_idx,3));
        vv(user_idx) = get_attenuation_factor(zk(user_idx,1:3),lammda);
        % a(:,b) = get_steering_vector(k_m,r(:,:,b),lammda);
        a_b = exp(-1i*2*pi/lammda*(k_m'* r_b)).';
        % g = get_antenna_pattern(k_m,R(:,:,b));        
        local_location = -R_b * k_m;
        local_location = (local_location)/vecnorm(local_location);
        theta_prime = acos(local_location(3));
        phi_prime = acos(local_location(1)/(sqrt(local_location(1)^2+local_location(2)^2)));
        a_H_E = -12 * ((phi_prime * 2.769) ^ 2 + ((theta_prime - pi/2 ) * 2.769) ^ 2 );
        a_gpu = 10^((a_H_E)/10);
        g_gpu = 7.943 * sqrt(a_gpu);
        % g_gpu = 7.943 * sqrt(max(10^(-10),a_gpu));
        G_b_k=a_b*g_gpu ;
        A_bb(:,user_idx)=G_b_k; 
    end
    A_b=A_bb.';
    sigm=diag(vv);
    P=transmit_power*ones(num_user,1);
    Lam=diag(P);
    WW=Lam^(0.5)*sigm'*A_b;
    W_sum = W_sum + WW * WW';
    for j = 1:size(W_s,3)
        if(j==b)
            continue;
        end
        W_sum = W_sum + W_s(:,:,j);
    end
    
    C_q_u_zk_new = real(log2(det(diag(ones(1,num_user)) + ...
        (1/noise_power)*W_sum)));
    end

end