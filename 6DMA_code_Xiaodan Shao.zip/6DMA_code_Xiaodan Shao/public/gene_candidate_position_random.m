% generate candidates using random initialization
function [q,u] = gene_candidate_position_random(region_size,B)

if(B == 16)
    B_max = 64;
elseif(B == 4)
    B_max = 12;
else
    assert(0);
end
[q_candidate, u_candidate] = gene_candidate_position_Fibonacci(region_size,B_max);

q_candidate = reshape(q_candidate,3,[]);
u_candidate = reshape(u_candidate,3,[]);
sel_list = randperm(B_max,B);
q = reshape(q_candidate(:,sel_list),[],1);
u = reshape(u_candidate(:,sel_list),[],1);

end


