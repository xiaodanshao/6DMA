function v_m = get_attenuation_factor(z,lammda)
loss_factor = -3;
d_break     = 10;
d_user = vecnorm(z);
v_m = sqrt((lammda/(4*pi*d_break))^2 * (d_user/d_break)^(loss_factor));
end