function [d_u,Hessian] = derivative_u(q_b,u_b,B_b,b,C_b,zk,k_m,B,N,lammda)
delta = 2^(-8);
d_u = zeros(3,1);
Hessian = (zeros(3,3));
f = zeros(1,8);
f(1) = real(C_b);
for i = 2:8
    d_u_indicator = zeros(3,1);
    tmp = dec2bin(i,3);
    for j = 1:3
        d_u_indicator(j) = str2double(tmp(j));
    end
    next_u = u_b + delta*d_u_indicator;
    f(i) = real(log_d(get_A_b(q_b,next_u,zk,b,k_m,B,N,lammda),B_b));
end

%% get Hessian matrix
for i = 1:3
    for j = i+1:3
        Hessian(i,j) = ((f(2^(i-1) + 2^(j-1) + 1) - f(2^(j-1) + 1))/delta - (f(2^(i-1) + 1) - f(0 + 1))/delta)/delta;
    end
end
Hessian = Hessian + Hessian.';
for i = 1:3
    next_u= u_b + 2 * delta; % q_i + 2*Delta
    f_2delta = log_d(get_A_b(q_b,next_u,zk,b,k_m,B,N,lammda),B_b);  % C(q_i + 2*Delta)
    Hessian(i,i) = (f_2delta - 2 * f(2^(i-1) + 1) + f(0 + 1))/(delta^2) ;
end
%% 一阶导
for i = 1:3
    d_u(i) = (f(2^(i-1) + 1) - C_b)/delta;
end
end