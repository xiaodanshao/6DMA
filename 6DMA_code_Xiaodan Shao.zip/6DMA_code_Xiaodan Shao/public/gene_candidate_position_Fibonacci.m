% generate candidates using Fibonacci initialization
function [q,u] = gene_candidate_position_Fibonacci(region_size,B)
positons = fibonacciSphere(B,region_size);
q_candidate = zeros(3,B); 
R = zeros(3,3,B);

% 随机初始化
offset_u = rand(3,1)*2*pi;
offset_R = get_rotation_matrix(offset_u);
positons = offset_R.' * positons;

for b = 1:B
    [~, theta, phi] = cartesian_to_spherical(positons(1,b), positons(2,b), positons(3,b));
    a_r = [sin(theta) * cos(phi); sin(theta) * sin(phi); cos(theta)];
    a_theta = [cos(theta) * cos(phi); cos(theta) * sin(phi); -sin(theta)];
    a_phi = [-sin(theta) * sin(phi); sin(theta) * cos(phi); 0];
    local_cordinate = [a_r,a_phi,a_theta];
    R(:,:,b) = local_cordinate^(-1);
    q_candidate(:,b) = positons(:,b);
end

q = q_candidate;
u = get_u_from_R(R);

% disp_units(reshape(q_candidate,[],1)',reshape(u_candidate,[],1),candidate_num_per_surface * 20,r_local);

% lammda = 0.125;
% r_local= [0,lammda/4,lammda/4;
%             0,-lammda/4,lammda/4;
%             0,-lammda/4,-lammda/4;
%             0,lammda/4,-lammda/4]' ;



q = reshape(q,[],1);
u = reshape(u,[],1);

% disp_units(q',u,16,r_local);

end

function points = fibonacciSphere(samples,r)
    points = zeros(samples, 3);
    phi = pi * (3. - sqrt(5.)); % 用于创建黄金分割
    y = 1 - (1 / samples);

    for i = 0:(samples - 1)
        y = 1 - i / (samples - 1) * 2; % 调整 y 的范围
        radius = sqrt(1 - y*y);

        theta = phi * i;
        points(i + 1, :) = r * [cos(theta) * radius, y, sin(theta) * radius];
    end
    points = points.';
end

function [r, theta, phi] = cartesian_to_spherical(x, y, z)
    % 计算极径
    r = sqrt(x^2 + y^2 + z^2);
    
    % 计算极角
    theta = acos(z / r);
    
    % 计算方位角
    phi = atan2(y, x);
    
end

