x = zeros(1,6*B);
zk = load("zk.mat");
zk = zk.zk;
B = 15;
N = 4;
u = x(1,3*B+1:6*B)';
q = x(1,1:3*B)';
K_trial = 3;
Fx = 0;
lammda = 3 * 10^8 / (2.4 * 10^9);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';
R = zeros(3,3,B);
r = zeros(3,N,B);
for b = 1:B
    q_b = q(3*(b - 1) + 1 : 3*b);
    u_b = u(3*(b - 1) + 1 : 3*b);
    R(:,:,b) = get_rotation_matrix(u_b);
    r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
end
penalty_factor = 100;
num_overlap = overlap_constraint(q,B,lammda);
num_blockage = blockage_constraint(q,R,r);
C_k_constriant = 0;
for i=1:K_trial
    C_k_constriant = C_k_constriant + user_capacity_constraint(R,r,zk{i},lammda);
end
C_k_constriant = C_k_constriant/K_trial;
% num_overlap = 0;
% num_blockage = 0;


% if((num_overlap > 0) || (num_blockage > 0) || (C_k_constriant > 0))
%     Fx = -(penalty_factor ) * (num_blockage + num_overlap + C_k_constriant);
% else
%     
    for i=1:K_trial
        Fx = Fx + get_capacity(q,u,R,r,zk{i},lammda); 
    end
    Fx = Fx/K_trial;
%end 
% Fx = Fx - penalty_factor * (num_blockage + num_overlap);
Fx = - Fx;



function [C_q_u_zk,Bb] = get_capacity(q,u,R,r,zk,lammda)
noise_power = 10^(-5); % Watt
pk = 0.04;
num_user = size(zk,1);
B = size(R,3);
N = 4;
a = zeros(N,B);
h = zeros(num_user,N*B);
%h1 = zeros(num_user,N*B);
A_bb = zeros(N,num_user);
Q_t= zeros(num_user,N);
Q_b= zeros((B-1)*N,num_user);
Q_bc = zeros(num_user,B*N);

for b = 1:B
     for user_idx = 1:num_user
        k_m = get_k_vector(zk(user_idx,1),zk(user_idx,2),zk(user_idx,3));
        v(user_idx) = get_attenuation_factor(zk(user_idx,:),lammda);
            a(:,b) = get_steering_vector(k_m,r(:,:,b),lammda);
            ge = get_antenna_pattern(k_m,R(:,:,b));
            G_b_k=a(:,b)*ge;
            h1(user_idx,N*(b - 1) + 1 : N*b) = get_channel_matrix(a(:,b),v(user_idx),ge);
            A_bb(:,user_idx)=G_b_k; 
     end
      A_b=A_bb.';
      A(:, N*(b - 1) + 1 : N*b) =A_b;
      sigm=diag(v);
      P=pk*ones(num_user,1);
      Lam=diag(P);
      Q_tilde=Lam^(0.5)*sigm'*A_b;
      Q_bc(:,N*(b - 1) + 1 : N*b)=Q_tilde;   
end

for b = 1:B
      Q_w=zeros(num_user,B*N);
      Q_w=Q_bc;
      Q_w(:,[N*(b - 1) + 1 : N*b])=[];
      Q_b=Q_w.';
      B_b=sigm*Lam^(0.5)*(eye(num_user)+1/noise_power*Q_b'*Q_b)^(-1)*Lam^(0.5)*sigm';
      C_b=log2(det(eye(N)+1/noise_power*A_b'*B_b*A_b));


      dererivative(q,u,B_b,b,C_b,zk)



      Bb(:,:,b)=B_b;
end


      h =A'*sigm;
      g=C_b;


C_q_u_zk = real(g);





end


% for b = 1:B
%     q_b = q(3*(b - 1) + 1 : 3*b);
%     detla=0.001;
%     for i = 1:3
%         e=zeros(3,1);
%         e(i)=1;
%         dff_q(i)=(q_b+detla*e)/detla;
%     end
% end

function A = get_b_Q(q,u,zk,b)
num_user = size(zk,1);
B = 1;
N = 4;
a = zeros(N,B);
A_bb = zeros(N,num_user);

lammda = 3 * 10^8 / (2.4 * 10^9);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';

q_b = q(3*(b - 1) + 1 : 3*b);
u_b = u(3*(b - 1) + 1 : 3*b);
R(:,:) = get_rotation_matrix(u_b);
r(:,:) = get_global_antenna_location(r_local,R(:,:),q_b);

 for user_idx = 1:num_user
    k_m = get_k_vector(zk(user_idx,1),zk(user_idx,2),zk(user_idx,3));
    a(:,b) = get_steering_vector(k_m,r(:,:),lammda);
    ge = get_antenna_pattern(k_m,R(:,:));
    G_b_k=a(:,b)*ge;
    A_bb(:,user_idx)=G_b_k; 
 end
 A_b=A_bb.';
 A =A_b;


end

function d_C = dererivative(q,u,Bb,b,C_b,zk)
delta = 2^(-16);
d_C = zeros(3,1);
for i = 1:3
    next_q = q;
    next_q(3*(b-1)+i) = q(3*(b-1)+i) + delta;
    d_C(i) = (log_d(get_b_Q(next_q,u,zk,b),Bb) - C_b)/delta;
end
end




function res = log_d(A,Bb)
N = 4;
noise_power = 10^(-5); % Watt
res = log2(det(eye(N)+1/noise_power*A'*Bb*A));
end

