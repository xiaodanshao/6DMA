% function [d_q,Hessian] = derivative_q(q_b,u_b,B_b,b,C_b,zk,k_m,B,N,lammda)
% delta = 2^(-8);
% d_q = zeros(3,1);
% Hessian = complex(zeros(3,3));
% f = zeros(1,8);
% f(1) = C_b;
% for i = 2:8
%     d_q_indicator = zeros(3,1);
%     tmp = dec2bin(i,3);
%     for j = 1:3
%         d_q_indicator(j) = str2double(tmp(j));
%     end
%     next_q = q_b + delta*d_q_indicator;
%     f(i) = log_d(get_A_b(next_q,u_b,zk,b,k_m,B,N,lammda),B_b);
% end
% 
% %% get Hessian matrix
% for i = 1:3
%     for j = i+1:3
%         Hessian(i,j) = ((f(2^(i-1) + 2^(j-1) + 1) - f(2^(j-1) + 1))/delta - (f(2^(i-1) + 1) - f(0 + 1))/delta)/delta; ;
%     end
% end
% Hessian = Hessian + Hessian.';
% for i = 1:3
%     next_q = q_b + 2 * delta; % q_i + 2*Delta
%     f_2delta = log_d(get_A_b(next_q,u_b,zk,b,k_m,B,N,lammda),B_b);  % C(q_i + 2*Delta)
%     Hessian(i,i) = (f_2delta - 2 * f(2^(i-1) + 1) + f(0 + 1))/(delta^2) ;
% end
% %% 一阶导
% for i = 1:3
%     d_q(i) = (f(2^(i-1) + 1) - C_b)/delta;
% end
% end
function d_q = derivative_q(q_b,R,B_b,b,C_b,zk,k_m,B,N,lammda)
delta = 2^(-16);
d_q = zeros(3,1);
%% 一阶导
for i = 1:3
    delta_q = zeros(3,1);
    delta_q(i) = delta;
    d_q(i) = (log_d(get_A_b(q_b + delta_q,R,zk,b,k_m,B,N,lammda),B_b) - C_b)/delta;
end
end
