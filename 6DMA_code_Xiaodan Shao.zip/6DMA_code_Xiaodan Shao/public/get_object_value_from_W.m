function [E_C] = get_object_value_from_W(noise_power,zk_tag,W)
K_trial = size(zk_tag,2);
E_C = 0;
num_total_user = zeros(K_trial,1);
for j = 1 : K_trial
    num_total_user(j) = size(zk_tag{j},1);
end

E_C_s = zeros(K_trial,1);

for i=1:K_trial

    [E_C_s(i)] = get_capacity_from_W(noise_power,zk_tag{i},W{i}); 

end

E_C = E_C + sum(E_C_s,"all")/K_trial;

E_C = real(E_C);



    function [C_q_u_zk_new] = get_capacity_from_W(noise_power,zk,W)
    num_user = size(zk,1);
    W_sum = zeros(num_user,num_user);
    for k = 1:size(W,3)
        W_sum = W_sum + W(:,:,k);
    end
    
      C_q_u_zk_new = real(log2(det(diag(ones(1,num_user)) + ...
            (1/noise_power)*W_sum)));
    end

end