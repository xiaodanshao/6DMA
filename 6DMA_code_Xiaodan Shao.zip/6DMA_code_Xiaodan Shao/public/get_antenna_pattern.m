function g_bm = get_antenna_pattern(k_m,R_b)
R_b = gpuArray(R_b);
k_m = gpuArray(k_m);
local_location = R_b * k_m;
local_location = (local_location)/vecnorm(local_location);
theta_prime = acos(local_location(3));
phi_prime = acos(local_location(1)/(sqrt(local_location(1)^2+local_location(2)^2)));

a_H = -12 * (phi_prime * 180 / 65) ^ 2;
a_E = -12 * ((theta_prime - pi/2 ) * 180 / 65) ^ 2;

a_gpu = 10^((a_H + a_E)/10);

a = gather(a_gpu);

if a < 10^(-3)
    g_bm = 10^(-3);
else
    g_bm = a;
end

% sqrt(G_max) = sqrt(10^(1.8)) = 7.943
g_bm = 7.943 * sqrt(g_bm);

end