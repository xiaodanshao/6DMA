clear;
power_result_CSM = load("power_result_CSM.mat");
power_result_random_AO = load("power_result_random_AO.mat");
power_result_CSM_AO = load("power_result_CSM_AO.mat");
power_result_sectorized = load("power_result_sectorized.mat");

for p_idx = 1:5
    power_result(p_idx,1) = power_result_CSM.result.value_CSSM{p_idx}(end);
    power_ln_result(p_idx,1) = power_result_CSM.result.ln_value_CSSM{p_idx}(end);

    power_result(p_idx,2) = power_result_random_AO.result.value_per_iter_region{p_idx}(end);
    power_ln_result(p_idx,2) = power_result_random_AO.result.ln_value_per_iter_region{p_idx}(end);

    power_result(p_idx,3) = power_result_CSM_AO.result.value_per_iter_region{p_idx}(end);
    power_ln_result(p_idx,3) = power_result_CSM_AO.result.ln_value_per_iter_region{p_idx}(end);
end

for i = 1:3
    plot(power_result(:,i),'-*');
    hold on
end



power_result_sectorized_real = load("power_result_sectorized_real.mat");
data = power_result_sectorized_real.power_save;
plot(data,'-*')

h=legend('CSM','Random AO','CSM AO','Sectorized BS');
set(h,'Interpreter','latex','FontSize',10)
xlabel('Angle Estimation Error (Degrees)','FontSize',12,'interpreter','latex');
ylabel('Received Signal Power (dBm)');