function q_next = solve_QP_q(q,u,d_q,delta,b,dmin,B)
N = 4;
lammda = 3 * 10^8 / (2.4 * 10^9);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';
q_b = real(q(3*(b - 1) + 1 : 3*b));
u_b = real(u(3*(b - 1) + 1 : 3*b));
R_b = get_rotation_matrix(u_b);
n_u_b = (R_b.') * [1;0;0];

A_1 = zeros(B-1,3);
b_1 = zeros(B-1,1);
A_2 = zeros(N*(B-1),3);
b_2 = zeros(N*(B-1),1);

% constraint 42A
H = delta;
f = -(d_q + delta * q_b);

% constraint 42A
lb = -0.5*ones(N*(B-1),1);
ub =  0.5*ones(N*(B-1),1);

for k = 1:B-1
    if(k==b)
        continue;
    end
    q_k = q(3*(k - 1) + 1 : 3*k);
    u_k = u(3*(k - 1) + 1 : 3*k);

    % constraint 49B
    a = vecnorm(q_k - q_b)^(-2);
    A_1(k,:) = a * (q_b - q_k).';
    b_1(k) = -1 * dmin  - a * (q_b - q_k).' * q_k;
    
    % constraint 42C
    R_k = get_rotation_matrix(u_k);
    r_k = get_global_antenna_location(r_local,R_k,q_k);
    for n = 1:N
        A_2(k,:) = -n_u_b.';
        b_2(k) = -n_u_b.' * r_k(:,n);
    end
end

q_next = quadprog(real(H),real(f),real([A_1;A_2]),real([b_1;b_2]),[],[],lb,ub);

end