
function Fx = AO_gradient(x)
B = 15;
zk = load("zk.mat");
zk = zk.zk;
N = 4;
K_trial = 3;
lammda = 3 * 10^8 / (2.4 * 10^9);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';
R = zeros(3,3,B);
r = zeros(3,N,B);

u = x(1,3*B+1:6*B)';
q = x(1,1:3*B)';

for b = 1:B
    q_b = q(3*(b - 1) + 1 : 3*b);
    u_b = u(3*(b - 1) + 1 : 3*b);
    R(:,:,b) = get_rotation_matrix(u_b);
    r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
end
penalty_factor = 100;
num_overlap = overlap_constraint(q,B,lammda);
num_blockage = blockage_constraint(q,R,r);

%% AO main funcation

if((num_overlap > 0) || (num_blockage > 0))
    Fx = penalty_factor * (num_overlap + num_blockage);
else
    save("q_initial_pso.mat",'q');
    save("R_initial_pso.mat",'R');
    iter=50;
    pk = 0.04;
    value_per_iter = zeros(1,iter);

    dmin = 3 * lammda;
    % P=pk*ones(num_user,1);
    % Lam=diag(P);
    
    for i = 1:K_trial
        % k_m = zeros(3,size(zk{i},1));
        k_m_i = zeros(3,size(zk{i},1));
        v_i = zeros(1,size(zk{i},1));
        num_user = size(zk{i},1);
        zk_i = zk{i};
        for user_idx = 1:num_user
            
            k_m_i(:,user_idx) = get_k_vector(zk_i(user_idx,1),zk_i(user_idx,2),zk_i(user_idx,3));
            v_i(user_idx) = get_attenuation_factor(zk_i(user_idx,:),lammda);
        end
        k_m{i} = k_m_i;
        sigm{i}=diag(v_i);
        Lam{i} = pk * eye(num_user);
    end
    
    for t = 1:iter
        
        for b = 1:B
            q_b = q(3*(b - 1) + 1 : 3*b);
            u_b = u(3*(b - 1) + 1 : 3*b);
            d_q = (zeros(3,1));
            Hessian = (zeros(3,3));
            for i = 1:K_trial
    
                A = get_A_b(q_b,u_b,zk{i},b,k_m{i},B,N,lammda);
                B_b = get_B_b(R,r,k_m{i},B,N,sigm{i},Lam{i},lammda);
                C_b = log_d(A,B_b);
        
                [d_q_i,Hessian_i]=derivative_q(q_b,u_b,B_b,b,C_b,zk{i},k_m{i},B,N,lammda);
    
                d_q = d_q + d_q_i;
                Hessian = Hessian + Hessian_i;
    
            end
            d_q = d_q/K_trial;
            Hessian = Hessian/K_trial;
            % delta = get_delta(Hessian);
                
            q_b_next = 0.0001 * d_q/vecnorm(d_q) + q_b; 
            q(3*(b - 1) + 1 : 3*b) = q_b_next;
    
            if(~check_feasible(q,u,N,B,lammda))
                q(3*(b - 1) + 1 : 3*b) = q_b;
                % q_b_next = solve_QP_q(q,u,d_q,Hessian,b,dmin,B);
                % q(3*(b - 1) + 1 : 3*b) = q_b_next;
                % if(~check_feasible(q,u,N,B,lammda))
                %     q(3*(b - 1) + 1 : 3*b) = q_b;
                % end
            end

            r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b_next);

        end
    
        
        for b = 1:B
            q_b = q(3*(b - 1) + 1 : 3*b);
            u_b = u(3*(b - 1) + 1 : 3*b);
            d_u = (zeros(3,1));
            Hessian = (zeros(3,3));
            for i = 1:K_trial
    
                A = get_A_b(q_b,u_b,zk{i},b,k_m{i},B,N,lammda);
                B_b = get_B_b(R,r,k_m{i},B,N,sigm{i},Lam{i},lammda);
                C_b = log_d(A,B_b);
        
                [d_u_i,Hessian_i]=derivative_u(q_b,u_b,B_b,b,C_b,zk{i},k_m{i},B,N,lammda);
    
                d_u = d_u + d_u_i;
                Hessian = Hessian + Hessian_i;
    
            end
            d_u = d_u/K_trial;
            Hessian = Hessian/K_trial;
            % delta = get_delta(Hessian);
                
            u_b_next = 0.0001 * d_u/vecnorm(d_u) + u_b ;
            u(3*(b - 1) + 1 : 3*b) = u_b_next;
    
            if(~check_feasible(q,u,N,B,lammda))
                u(3*(b - 1) + 1 : 3*b) = u_b;
                % u_b_next = solve_QP_u(q,u,d_u,Hessian,b,B);
                % u(3*(b - 1) + 1 : 3*b) = u_b_next;
                % if(~check_feasible(q,u,N,B,lammda))
                %     u(3*(b - 1) + 1 : 3*b) = u_b;
                % end
            end

            R(:,:,b) = get_rotation_matrix(u_b_next);

        end
    
        % value_per_iter(t) = get_object_value(q,u,zk,N,B,lammda);
        % value_per_iter(t)
    
    end
    
    plot(value_per_iter);
    close all
    Fx = -1 * get_object_value(q,u,zk,N,B,lammda);
end

end

function [d_q,E_C] = get_d_q(q,u,zk,N,B,lammda,b)
delta = 2^(-16);
d_q = zeros(3,1);
E_C = get_object_value(q,u,zk,N,B,lammda);
for i = 1:3
    delta_q = zeros(3,1);
    delta_q(i) = delta;
    q_b_next = q(3*(b - 1) + 1 : 3*b) + delta_q;
    q_next = q;
    q_next(3*(b - 1) + 1 : 3*b) = q_b_next;
    d_q(i) = (get_object_value(q_next,u,zk,N,B,lammda) - E_C)/delta;
end

end

function [d_u,E_C] = get_d_u(q,u,zk,N,B,lammda,b)
delta = 2^(-16);
d_u = zeros(3,1);
E_C = get_object_value(q,u,zk,N,B,lammda);
for i = 1:3
    delta_u = zeros(3,1);
    delta_u(i) = delta;
    u_b_next = q(3*(b - 1) + 1 : 3*b) + delta_u;
    u_next = q;
    u_next(3*(b - 1) + 1 : 3*b) = u_b_next;
    d_u(i) = (get_object_value(q,u_next,zk,N,B,lammda) - E_C)/delta;
end

end