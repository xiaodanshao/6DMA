function zk_s = get_zk_s(zk_tag,s)

for i = 1:size(zk_tag,2)
    zk_i = zk_tag{i};
    zk_i = zk_i(zk_i(:,4)==s,:);
    zk_s{i} = zk_i;
end

end