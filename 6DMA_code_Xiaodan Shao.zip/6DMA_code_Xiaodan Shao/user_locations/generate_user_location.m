
function zk = generate_user_location(K)
% background_ratio = [0, 0.2, 0.4, 0.6, 0.8, 1];
background_ratio = [0.2];
% mu_list = [10,20,30,40,50];
mu_list = [35];
for mu_idx = 1:1
    mu = mu_list(mu_idx);
    Trial_list = poissrnd(mu,K);
    for density_idx = 1:1
        for k = 1:length(Trial_list)
            zk{k} = generate_user_location_given_K(Trial_list(k),background_ratio(density_idx));
        end
        save("user_locations/default_zk.mat","zk");
        % save("density_zk_" + num2str(density_idx) +".mat","zk");
        % save("user_zk_" + num2str(mu_idx) +".mat","zk");
    end
end

background_ratio = [0, 0.2, 0.4, 0.6, 0.8, 1];
% background_ratio = [0.2];
% mu_list = [10,20,30,40,50];
mu_list = [35];
for mu_idx = 1:1
    mu = mu_list(mu_idx);
    Trial_list = poissrnd(mu,K);
    for density_idx = 1:6
        for k = 1:length(Trial_list)
            zk{k} = generate_user_location_given_K(Trial_list(k),background_ratio(density_idx));
        end
        % save("default_zk.mat","zk");
        save("user_locations/density_zk_" + num2str(density_idx) +".mat","zk");
        % save("user_zk_" + num2str(mu_idx) +".mat","zk");
    end
end

% background_ratio = [0, 0.2, 0.4, 0.6, 0.8, 1];
background_ratio = [0.2];
mu_list = [10,20,30,40,50];
% mu_list = [25];
for mu_idx = 1:5
    mu = mu_list(mu_idx);
    Trial_list = poissrnd(mu,K);
    for density_idx = 1:1
        for k = 1:length(Trial_list)
            zk{k} = generate_user_location_given_K(Trial_list(k),background_ratio(density_idx));
        end
        % save("default_zk.mat","zk");
        % save("density_zk_" + num2str(density_idx) +".mat","zk");
        save("user_locations/user_zk_" + num2str(mu_idx) +".mat","zk");
    end
end
end

function zk = generate_user_location_given_K(num,background_ratio)

%% parameter set-up
a_1 = [-1; 0; -0.75]/vecnorm([-1; 0; -0.75]);
o_1 = 40 * a_1;
r_1 = 5;
num_1 = ceil(num * (1 - background_ratio) * 1/6);

a_2 = [1; 2; 2]/vecnorm([1; 2; 2]);
o_2 = 60 * a_2;
r_2 = 10;
num_2 = ceil(num * (1 - background_ratio) * 2/6);

a_3 = [1; 0; -0.5]/vecnorm([1; 0; -0.5]);
o_3 = 100 * a_3;
r_3 = 15;
num_3 = ceil(num * (1 - background_ratio) * 3/6);

r_b_lower = 20;
r_b_upper = 200;
num_b = max(0,num - num_1 - num_2 - num_3);

hotspot_loc = [o_1, o_2, o_3];
hotspot_radius = [r_1 r_2 r_3];
hotspot_num = [num_1 num_2 num_3];

zk = [];

%% generate users in the hotspots
for i = 1:3
    r = (hotspot_radius(i).^3 *rand(hotspot_num(i),1)).^(1/3);
    theta = acos(1 - 2*rand(hotspot_num(i),1));
    phi  = 2*pi*rand(hotspot_num(i),1);
    z_i = zeros(hotspot_num(i),3);
    z_i(:,1:3) = [r.*sin(theta).*cos(phi),r.*sin(theta).*sin(phi),r.*cos(theta)] + repmat(hotspot_loc(:,i)',hotspot_num(i),1);
    zk = [zk;z_i];
end

%% generate users in the background
r = (r_b_lower^3 + (r_b_upper^3 - r_b_lower^3)*rand(num_b,1)).^(1/3);
theta = acos(1 - 2*rand(num_b,1));
phi  = 2*pi*rand(num_b,1);
z_i = zeros(num_b,3);
z_i(:,1:3) = [r.*sin(theta).*cos(phi),r.*sin(theta).*sin(phi),r.*cos(theta)];
zk = [zk;z_i];

end