% d_k: gradient direction
% f_d: feasible direction
function alpha = find_stepsize_q(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local,d_k,f_d,F_x,b,W)
sigma = 10^(-2);
beta = 0.5;
s = 0.5;
% get_object_value(q,u,zk,zk_tag,N,B,lammda);
q_b = q(3*(b - 1) + 1 : 3*b);
m = 0;
while(1)
    alpha = beta^m * s;
    q(3*(b - 1) + 1 : 3*b) = q_b + alpha * f_d;
    if(get_object_value_rec(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W) - ...
            F_x >= sigma * beta^m * s * d_k' * f_d)
        break;
    end
    if(m>10)
        alpha = 0;
        break;
    end
    m = m+1;
end

end