function u = get_u_from_R(R)
B = size(R,3);
u = zeros(3,B);
for b = 1:B

    u(:,b) = [-asin(R(1,3,b));
                                atan2(R(2,3,b),R(3,3,b));
                                atan2(R(1,2,b),R(1,1,b))];

end

end
