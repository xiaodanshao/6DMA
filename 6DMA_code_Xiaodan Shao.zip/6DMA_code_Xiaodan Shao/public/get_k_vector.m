function k_m = get_k_vector(x,y,z)
k_m = -[x,y,z]';
k_m = k_m/vecnorm(k_m);
end