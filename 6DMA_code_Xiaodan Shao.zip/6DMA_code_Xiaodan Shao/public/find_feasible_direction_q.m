function [d_k_q,d_q,Fx] = find_feasible_direction_q(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local,region_size,b,W)

[d_q,Fx] = get_d_q(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W);
q_b = q(3*(b - 1) + 1 : 3*b);
if(N == 1)
    d_min = 0.25 * lammda;
elseif(N == 4)
    d_min = (sqrt(2)/2 + 1/4) * lammda;
elseif(N == 16)
    d_min = (3/2 * sqrt(2) + 1/2) * lammda;
end

% object function
c = -d_q';

% constraint (42B)
lb = -region_size * ones(3,1);
ub = region_size * ones(3,1);

% relaxed constraint (42C)
A_1 = zeros((B-1),3);
b_1 = zeros((B-1),1);
j = 1;
for i = 1:B
    if(i == b)
        continue;
    end
    q_j = q(3*(i - 1) + 1 : 3*i);
    n = q_j - q_b;
    q_boundary = q_j - (d_min/vecnorm(n)) * n;
    A_1(j,:) = n';
    b_1(j,1) = n' * q_boundary;
    j = j+1;    
end

% constraint (42D)
u_b = u(3*(b - 1) + 1 : 3*b);
R_b = get_rotation_matrix(u_b);
A_2 = zeros(2 * (B-1),3);
b_2 = zeros(2 * (B-1),1);
j = 1;
for i = 1:B
    if(i == b)
        continue;
    end
    q_j = q(3*(i - 1) + 1 : 3*i);
    u_j = u(3*(i - 1) + 1 : 3*i);
    n = R_b' * [1,0,0]';
    A_2(j,:) = -n';
    b_2(j,1) = -n' * q_j;

    R_j = get_rotation_matrix(u_j);
    n = R_j' * [1,0,0]';
    A_2(B - 1 + j,:) = n';
    b_2(B - 1 + j,1) = n' * q_j;

    j = j+1;
end

% constriant new
A_3 = -(R_b' * [1,0,0]')';
b_3 = 0;

options = optimoptions('linprog', 'Display', 'off');

[d_k_q,~,~,~] = linprog(c,[A_1;A_2;A_3],[b_1;b_2;b_3],[],[],lb,ub,options);
if(isempty(d_k_q))
    d_k_q = [0;0;0];
else
    d_k_q = d_k_q - q_b;
end
end

function [d_q,E_C] = get_d_q(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W)
delta = 2^(-16);
d_q = zeros(3,1);
E_C = get_object_value_from_W(noise_power,zk_tag,W);
for j = 1:3
    delta_q = zeros(3,1);
    delta_q(j) = delta;
    q_b_next = q(3*(b - 1) + 1 : 3*b) + delta_q;
    q_next = q;
    q_next(3*(b - 1) + 1 : 3*b) = q_b_next;

    [E_C_next] =...
        get_object_value_rec(q_next,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W);

    d_q(j) = (E_C_next - E_C)/delta;
end

end