function B_b = get_B_b(R,r,k_m,B,N,sigm,Lam,lammda)
K = size(Lam,1);
noise_power = 10^(-5); % Watt
a = zeros(N,B);
A_bb = zeros(N,K);
Q_bc = zeros(K,B*N);

for b = 1:B
     for user_idx = 1:K
            a(:,b) = get_steering_vector(k_m(:,user_idx),r(:,:,b),lammda);
            ge = get_antenna_pattern(k_m(:,user_idx),R(:,:,b));
            G_b_k=a(:,b)*ge;
            A_bb(:,user_idx)=G_b_k; 
     end
      A_b=A_bb.';
      Q_tilde=Lam^(0.5)*sigm'*A_b;
      Q_bc(:,N*(b - 1) + 1 : N*b)=Q_tilde;   
end

Q_w=Q_bc;
Q_w(:,N*(b - 1) + 1 : N*b)=[];
Q_b=Q_w.';
B_b=sigm*Lam^(0.5)*(eye(K)+1/noise_power*(Q_b')*Q_b)^(-1)*Lam^(0.5)*sigm';
end