function distantce = distantce_constraint(q,alpha,beta,gamma)
% [q,alpha,beta,gamma,~,~] = get_para(x);
B = 2;
N = 4;
lammda = 3 * 10^8 / (2.4 * 10^9);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';

% pair_number = nchoosek(N*B,2);
distantce = zeros(1,N*B);

R = zeros(3,3,B);
r = zeros(3,N,B);

for b = 1 : B
    R(:,:,b) = get_rotation_matrix(alpha(b),beta(b),gamma(b));
    r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q(:,b));
end

k = 1;
for i = 0 : N*B-1
    for j = 0 : N*B-1
        if(i == j)
            continue;
        end
        distantce(k) = vecnorm(r(:,mod(i,N)+1,ceil((i+1)/(N)) ) - r(:,mod(j,N)+1,ceil((j+1)/(N))));
        distantce(k) = lammda/2 - distantce(k);
        k = k+1;
    end
end
end