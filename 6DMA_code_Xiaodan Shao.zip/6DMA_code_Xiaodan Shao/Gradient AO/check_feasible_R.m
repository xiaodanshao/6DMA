% function is_feasible = check_feasible(q,u,N,B,lammda)
% r = zeros(3,N,B);
% r_local = [0,lammda/4,lammda/4;
%     0,-lammda/4,lammda/4;
%     0,-lammda/4,-lammda/4;
%     0,lammda/4,-lammda/4]';
% 
% 
% for b = 1:B
%     q_b = q(3*(b - 1) + 1 : 3*b);
%     u_b = u(3*(b - 1) + 1 : 3*b);
%     R(:,:,b) = get_rotation_matrix(u_b);
%     r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
% end
% num_overlap = overlap_constraint(q,B,lammda);
% num_blockage = blockage_constraint(q,R,r);
% num_region = region_constraint(q);
% is_feasible = ((num_overlap==0) && (num_blockage==0) &&(num_region ==0)  );
% end

function is_feasible = check_feasible_R(q,R,N,B,lammda)
r = zeros(3,N,B);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';


for b = 1:B
    q_b = q(3*(b - 1) + 1 : 3*b);
    r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
end
num_overlap = overlap_constraint(q,B,lammda);
num_blockage = blockage_constraint(q,R,r);
num_region = region_constraint(q);
is_feasible = ((num_overlap==0) && (num_blockage==0) &&(num_region ==0)  );
end