function a_bm = get_steering_vector(k_m,r_bn,lammda)
k_m = gpuArray(k_m);
r_bn = gpuArray(r_bn);
lammda = gpuArray(lammda);
gpu_a_bm = exp(-1i*2*pi/lammda*(k_m'* r_bn)).';
a_bm = gather(gpu_a_bm);
% a_bm = exp(a_bm);
% a_bm = a_bm.';
end