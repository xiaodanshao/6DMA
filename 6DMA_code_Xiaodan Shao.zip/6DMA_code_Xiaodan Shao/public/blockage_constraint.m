function num_blockage = blockage_constraint(q,R,r)
% [q,alpha,beta,gamma,~,~] = get_para(x);
B = size(R,3);
% N = 4;
num_blockage = 0;
for i = 1 : B
    norm = R(:,:,i)' * [1;0;0];
    q_b = q(3*(i-1)+1:3*i,1);
    for j = 1 : B
        if(i == j)
            continue;
        end
        % for n = 1 : N
        %     if(norm' * (r(:,n,j) - q_b) > 0.1)
        %         num_blockage = num_blockage + 10 * (exp(norm' * (r(:,n,j) - q_b))-1);
        %     end
        %     k = k+1;
        % end
        q_j = q(3*(j-1)+1:3*j,1);
        if(norm' * (q_j - q_b)/vecnorm(q_j - q_b) > 0.001)
            num_blockage = num_blockage + 10 * (exp(norm' * (q_j - q_b)/vecnorm(q_j - q_b) - 0.001));
        end
    end
end
end