function u_next = solve_QP_u(q,u,d_u,delta,b,B)
N = 4;
lammda = 3 * 10^8 / (2.4 * 10^9);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';
A_1 = zeros(N*(B-1),3);
b_1 = zeros(N*(B-1),1);

q_b = real(q(3*(b - 1) + 1 : 3*b));
u_b = real(u(3*(b - 1) + 1 : 3*b));
R_b = get_rotation_matrix(u_b);
n_u_b = (R_b.') * [1;0;0];

% object function 
H = delta;
f = -(d_u + delta * u_b);

% constraint 50B
lb = 0*ones(N*(B-1),1);
ub = 2*pi*ones(N*(B-1),1);

for j = 1:B-1
    if(j==b)
        continue;
    end

    % constraint 50A
    q_j = q(3*(j - 1) + 1 : 3*j);
    u_j = u(3*(j - 1) + 1 : 3*j);
    r_j = get_global_antenna_location(r_local,get_rotation_matrix(u_j),q_j);
    for n = 1:N
        PI_vector = get_pi_vector(R_b,u_b,r_j(:,n),q_b);
        A_1(j,:) = -PI_vector;
        b_1(j) = n_u_b * (q_b - r_j(:,n)) - PI_vector * u_b;
    end
end

u_next = quadprog(real(H),real(f),real(A_1),real(b_1),[],[],lb,ub);

end

function PI_vector = get_pi_vector(R_b,u_b,r_b_j,q_b)

delta = 2^(-16);
dR = zeros(3,3,3);
dR(:,:,1) = (get_rotation_matrix(u_b + delta * [1;0;0]) - R_b)/delta;
dR(:,:,2) = (get_rotation_matrix(u_b + delta * [0;1;0]) - R_b)/delta;
dR(:,:,3) = (get_rotation_matrix(u_b + delta * [0;0;1]) - R_b)/delta;
PI_alpha = [1,0,0] * dR(:,:,1) * (r_b_j - q_b);
PI_beta = [1,0,0] * dR(:,:,2) * (r_b_j - q_b);
PI_gamma = [1,0,0] * dR(:,:,3) * (r_b_j - q_b);
PI_vector = -1*[PI_alpha;PI_beta;PI_gamma];

end