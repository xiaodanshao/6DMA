function num_orientation = orientation_constriant(q,R)
B = size(R,3);
num_orientation = 0;
for i = 1 : B
    norm = R(:,:,i)' * [1;0;0];
    q_b = q(3*(i-1)+1:3*i,1);
    if norm' * q_b < -0.001
        num_orientation = num_orientation + 1;
    end
end
end