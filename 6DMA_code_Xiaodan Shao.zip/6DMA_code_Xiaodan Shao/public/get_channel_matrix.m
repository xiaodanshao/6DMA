function h_bk = get_channel_matrix(a_b,v,g)
a_b = gpuArray(a_b);
v = gpuArray(v);
g = gpuArray(g);
h_bk_gpu = g * v * a_b.';
h_bk = gather(h_bk_gpu);
end