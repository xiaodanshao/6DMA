%% Xiaodan Shao, Please cite the article
% [1] X. Shao, Q. Jiang, and R. Zhang. 6D movable antenna based on user distribution: 
% Modeling and optimization. arXiv preprint arXiv:2403.08123, 2024.
%[2] X. Shao, R. Zhang, Q. Jiang, and R.Schober. 6D movable antenna enhanced wireless network 
% via discrete position and rotation optimization. arXiv preprint arXiv:2403.17122, 2024.
clear;
%% parameter set-up
N_total = 64;
N_candidate = [4 16];
user_number = [10 20 30 40 50];
transmit_power = [20 40 60 80 100 120] * 10^(-3);
region_size = 0.6;

B_candidate = N_total./ N_candidate;
lammda = 0.125;
noise_power = 10^(-8);
r_local{1} =   lammda * [0,      1/4,        1/4;
                         0,      -1/4,       1/4;
                         0,      -1/4,       -1/4;
                         0,      1/4,        -1/4]' ;
r_local{2}  =   lammda * [0,        -3/4,       3/4;
                          0         -1/4,       3/4;
                          0,         1/4,       3/4;
                          0,         3/4,       3/4;
                          0,        -3/4,       1/4;
                          0         -1/4,       1/4;
                          0,         1/4,       1/4;
                          0,         3/4,       1/4;
                          0,        -3/4,       -1/4;
                          0         -1/4,       -1/4;
                          0,         1/4,       -1/4;
                          0,         3/4,       -1/4;
                          0,        -3/4,       -3/4;
                          0         -1/4,       -3/4;
                          0,         1/4,       -3/4;
                          0,         3/4,       -3/4;]';

iter = 20;


%% picture 2 analysis of average user number
power_idx = 2;
density_idx = 2;
N_idx = 1;
for num_idx = 1:5
    zk_tag = load("user_locations/user_zk_" + num2str(num_idx) + ".mat");
    zk_tag = zk_tag.zk;
    best_val_AO = -inf;

    % proposed AO
    for i = 1:10
        [q_initial_AO,u_initial_AO] =...
            gene_candidate_position_random(region_size,B_candidate(N_idx));
        [initial_val_AO,value_per_iter_AO,q_opt_AO,u_opt_AO] = ...
            CSM_AO_u(q_initial_AO,u_initial_AO,N_candidate(N_idx),B_candidate(N_idx),transmit_power(power_idx),noise_power,lammda,r_local{N_idx},iter,zk_tag,region_size);
        
        result.value_per_iter_AO_user_num{num_idx,i} = value_per_iter_AO;
        
        if (value_per_iter_AO(end) > best_val_AO)
            best_val_AO = value_per_iter_AO(end);
            result.q_initial_AO_user_num{num_idx} = q_initial_AO;
            result.u_initial_AO_user_num{num_idx} = u_initial_AO;
            result.initial_val_AO_user_num{num_idx} = initial_val_AO;
            % result.value_per_iter_AO_user_num{num_idx} = value_per_iter_AO;
            result.q_opt_AO_user_num{num_idx} = q_opt_AO;
            result.u_opt_AO_user_num{num_idx} = u_opt_AO;
        end
    end


end

iter = 20;
%% picture 3 power law
N_idx = 1;
zk_tag = load("user_locations/density_zk_2.mat");
zk_tag = zk_tag.zk;
for power_idx = 1:6

    best_val_AO = -inf;

    % proposed AO
    for i = 1:10
        [q_initial_AO,u_initial_AO] =...
            gene_candidate_position_random(region_size,B_candidate(N_idx));
        [initial_val_AO,value_per_iter_AO,q_opt_AO,u_opt_AO] = ...
            CSM_AO_u(q_initial_AO,u_initial_AO,N_candidate(N_idx),B_candidate(N_idx),transmit_power(power_idx),noise_power,lammda,r_local{N_idx},iter,zk_tag,region_size);
        
        result.value_per_iter_AO_power_law{power_idx,i} = value_per_iter_AO;
        
        if (value_per_iter_AO(end) > best_val_AO)
            best_val_AO = value_per_iter_AO(end);
            result.q_initial_AO_power_law{power_idx} = q_initial_AO;
            result.u_initial_AO_power_law{power_idx} = u_initial_AO;
            result.initial_val_AO_power_law{power_idx} = initial_val_AO;
            % result.value_per_iter_AO_power_law{power_idx} = value_per_iter_AO;
            result.q_opt_AO_power_law{power_idx} = q_opt_AO;
            result.u_opt_AO_power_law{power_idx} = u_opt_AO;
        end
    end


end

%% picture 4 density law
N_idx = 1;
power_idx = 2;
for density_idx = 1:6
    zk_tag = load("user_locations/density_zk_" + num2str(density_idx) + ".mat");
    zk_tag = zk_tag.zk;
    best_val_AO = -inf;

    % proposed AO
    for i = 1:10
        [q_initial_AO,u_initial_AO] =...
            gene_candidate_position_random(region_size,B_candidate(N_idx));
        [initial_val_AO,value_per_iter_AO,q_opt_AO,u_opt_AO] = ...
            CSM_AO_u(q_initial_AO,u_initial_AO,N_candidate(N_idx),B_candidate(N_idx),transmit_power(power_idx),noise_power,lammda,r_local{N_idx},iter,zk_tag,region_size);
        
        result.value_per_iter_AO_density_law{density_idx,i} = value_per_iter_AO;
        
        if (value_per_iter_AO(end) > best_val_AO)
            best_val_AO = value_per_iter_AO(end);
            result.q_initial_AO_density_law{density_idx} = q_initial_AO;
            result.u_initial_AO_density_law{density_idx} = u_initial_AO;
            result.initial_val_AO_density_law{density_idx} = initial_val_AO;
            
            result.q_opt_AO_density_law{density_idx} = q_opt_AO;
            result.u_opt_AO_density_law{density_idx} = u_opt_AO;
        end
    end


end

save("result_19_Feb_AO.mat","result");

    