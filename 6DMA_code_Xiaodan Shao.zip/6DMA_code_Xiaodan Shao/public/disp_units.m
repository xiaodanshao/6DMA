% input : row vector
function disp_units(q,u,B,r_local,z,bg_ratio)
% zk = load("zk.mat");
% z = zk.zk;
K_trial = size(z,2);
% zk = [z{1};z{2};z{3}];
% lammda = 0.125;
% r_local = [0,lammda/4,lammda/4;
%     0,-lammda/4,lammda/4;
%     0,-lammda/4,-lammda/4;
%     0,lammda/4,-lammda/4]';
% for k = 1:K_trial
%     zk = z{k};
%     plot3(zk(:,1),zk(:,2),zk(:,3),'o');
%     hold on
% end
a_1 = [-1; 0; -0.75]/vecnorm([-1; 0; -0.75]);
o_1 = 40 * a_1;
r_1 = 5;

a_2 = [1; 2; 2]/vecnorm([1; 2; 2]);
o_2 = 60 * a_2;
r_2 = 10;

a_3 = [1; 0; -0.5]/vecnorm([1; 0; -0.5]);
o_3 = 100 * a_3;
r_3 = 15;

r_b_lower = 20;
r_b_upper = 200;

hotspot_loc = [o_1, o_2, o_3];
hotspot_radius = [r_1 r_2 r_3];
for i = 1:3
    [theta,phi] = meshgrid(linspace(0,2*pi,50),linspace(0,pi,50));
    X = hotspot_loc(1,i) + hotspot_radius(i)*sin(phi).*cos(theta);
    Y = hotspot_loc(2,i) + hotspot_radius(i)*sin(phi).*sin(theta);
    Z = hotspot_loc(3,i) + hotspot_radius(i)*cos(phi);
    surf(X,Y,Z,'EdgeColor','none','FaceAlpha',num2str(0.5*(1-bg_ratio)))
    hold on
end

[theta,phi] = meshgrid(linspace(0,2*pi,50),linspace(0,pi,50));
    X = 0 + 200*sin(phi).*cos(theta);
    Y = 0 + 200*sin(phi).*sin(theta);
    Z = 0 + 200*cos(phi);
    surf(X,Y,Z,'EdgeColor','none','FaceAlpha',num2str(0.1*bg_ratio),'FaceColor','cyan')
    hold on

[theta,phi] = meshgrid(linspace(0,2*pi,50),linspace(0,pi,50));
    X = 0 + 20*sin(phi).*cos(theta);
    Y = 0 + 20*sin(phi).*sin(theta);
    Z = 0 + 20*cos(phi);
    surf(X,Y,Z,'EdgeColor','none','FaceAlpha',num2str(0.2*bg_ratio),'FaceColor','white')
    hold on



for b = 1:B
    u_b = u(3*(b - 1) + 1 : 3*b)';
    R_b = get_rotation_matrix(u_b);
    q_b = q(3*(b - 1) + 1 : 3*b)';
    r_b = get_global_antenna_location(r_local,R_b,q_b);
    % r_global = r_global';
    scale = 20;
    norm_tail = R_b' * [1;0;0] * scale + q_b;
    

    % Plot outline of FA units
    plot3(norm_tail(1),norm_tail(2),norm_tail(3),'b*','LineWidth',0.05);
    hold on
    t = linspace(0,1,20);
    % edge_1 = r_b(:,3) + (r_b(:,19) - r_b(:,3)) .* t;
    % edge_2 = r_b(:,6) + (r_b(:,3) - r_b(:,6)) .* t;
    % edge_3 = r_b(:,22) + (r_b(:,6) - r_b(:,22)) .* t;
    % edge_4 = r_b(:,19) + (r_b(:,22) - r_b(:,19)) .* t;

    edge_1 = r_b(:,1) + (r_b(:,2) - r_b(:,1)) .* t;
    edge_2 = r_b(:,2) + (r_b(:,3) - r_b(:,2)) .* t;
    edge_3 = r_b(:,3) + (r_b(:,4) - r_b(:,3)) .* t;
    edge_4 = r_b(:,4) + (r_b(:,1) - r_b(:,4)) .* t;
    outline = [edge_1,edge_2,edge_3,edge_4];
    plot3(outline(1,:),outline(2,:),outline(3,:),'LineWidth',0.05);
    hold on
    norm_line = q_b + (norm_tail - q_b) .* t;
    plot3(norm_line(1,:),norm_line(2,:),norm_line(3,:),'LineWidth',0.05);
    if(b ~= B)
        hold on
    end
end
% for user_idx = 1:size(zk,1)
% 
% end
xlabel("X");
ylabel("Y");
zlabel("Z");
grid on
axis equal  
end