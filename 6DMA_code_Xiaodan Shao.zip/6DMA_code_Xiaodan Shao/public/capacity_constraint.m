function capacity_penalty = capacity_constraint(q,u,zk_tag,N,B,lammda)
capacity_penalty = 0;
cluster_num = 3;
% capacity_th = 1;
for cluster_idx = 1:cluster_num
    zk_s = get_zk_s(zk_tag,cluster_idx);
    cluter_capacity = get_object_value(q,u,zk_s,N,B,lammda);
    % capacity_penalty = capacity_penalty + max(0,exp(capacity_th - cluter_capacity)-1);
    capacity_penalty = capacity_penalty + min(log2(cluter_capacity/3),0);
end
end



function E_C = get_object_value(q,u,zk,N,B,lammda)
K_trial = size(zk,1);
r_local = [0,lammda/4,lammda/4;
    0,-lammda/4,lammda/4;
    0,-lammda/4,-lammda/4;
    0,lammda/4,-lammda/4]';
R = zeros(3,3,B);
r = zeros(3,N,B);
for b = 1:B
    q_b = q(3*(b - 1) + 1 : 3*b);
    u_b = u(3*(b - 1) + 1 : 3*b);
    R(:,:,b) = get_rotation_matrix(u_b);
    r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
end
E_C = 0;



for i=1:K_trial
    E_C = E_C + get_capacity(R,r,zk{i},lammda); 
end
E_C = E_C/K_trial;
end

% function C_k = capacity_constraint(R,r,zk,lammda)
% zk = [zk{1};zk{2};zk{3}];
% noise_power = 10^(-5); % Watt
% pk = 0.04;
% num_user = size(zk,1);
% B = size(R,3);
% N = 4;
% a = zeros(N,B);
% h = zeros(num_user,N*B);
% C_k = 0;
% 
% 
% 
% 
% 
% for user_idx = 1:num_user
%     k_m = get_k_vector(zk(user_idx,1),zk(user_idx,2),zk(user_idx,3));
%     v = get_attenuation_factor(zk(user_idx,:),lammda);
%     for b = 1:B
%         a(:,b) = get_steering_vector(k_m,r(:,:,b),lammda);
%         g = get_antenna_pattern(k_m,R(:,:,b));
%         h(user_idx,N*(b - 1) + 1 : N*b) = get_channel_matrix(a(:,b),v,g);
%     end
%     Ck = log2(1 + pk * h(user_idx,:) * h(user_idx,:)'/noise_power);
%     % C_k_th = 0.001;
%     % if(Ck < C_k_th)
%         C_k = C_k + min(log(100*Ck),0);
%     % end
% end
% C_k = real(C_k)/3;
% end