function d_R = derivative_R(q_b,R,B_b,b,C_b,zk,k_m,B,N,lammda)
delta = 2^(-16);
% for i = 2:8
%     d_u_indicator = zeros(3,1);
%     tmp = dec2bin(i,3);
%     for j = 1:3
%         d_u_indicator(j) = str2double(tmp(j));
%     end
%     next_u = u_b + delta*d_u_indicator;
%     f(i) = real(log_d(get_A_b(q_b,next_u,zk,b,k_m,B,N,lammda),B_b));
% end

%% 一阶导

d_R = zeros(3,3);
for i = 1:3
    for j = 1:3
        delta_R = zeros(3,3);
        delta_R(i,j) = delta;
        d_R(i,j) = ...
            (log_d(get_A_b(q_b,R + delta_R,zk,b,k_m,B,N,lammda),B_b) - C_b)/delta;
    end
end

end