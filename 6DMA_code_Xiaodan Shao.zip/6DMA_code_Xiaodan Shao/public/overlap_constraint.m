function num_overlap = overlap_constraint(q,B,lammda,N)
num_overlap = 0;
if(N == 1)
    d_min = 0.25 * lammda;
elseif(N == 4)
    d_min = (sqrt(2)/2 + 1/4) * lammda;
elseif(N == 16)
    d_min = (3/2 * sqrt(2) + 1/2) * lammda;
else
    d_min = 0;
%     disp("注意，未考虑overlap约束")
end
for i = 1:B
    q_i = q(3*(i-1)+1:3*i,1);
    for j = 1:B
        if (i==j)
            continue;
        end
        q_j = q(3*(j-1)+1:3*j,1);
        if(vecnorm(q_i-q_j) - d_min < -0.01)
            num_overlap = num_overlap + 10 * (exp(-0.01 + d_min - vecnorm(q_i-q_j) ));
        end
    end
end
num_overlap = num_overlap/2;
end
