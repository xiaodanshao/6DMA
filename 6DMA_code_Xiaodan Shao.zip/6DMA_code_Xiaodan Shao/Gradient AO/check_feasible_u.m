function is_feasible = check_feasible_u(q,u,N,B,lammda,r_local,~)
r = zeros(3,N,B);
R = zeros(3,3,B);

for b = 1:B
    q_b = q(3*(b - 1) + 1 : 3*b);
    u_b = u(3*(b - 1) + 1 : 3*b);
    R(:,:,b) = get_rotation_matrix(u_b);
    r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
end
num_overlap = overlap_constraint(q,B,lammda,N);
num_blockage = blockage_constraint(q,R,r);
num_orientation = orientation_constriant(q,R);
is_feasible = ((num_overlap<0.01) && (num_blockage<0.01) &&(num_orientation ==0)  );
end

