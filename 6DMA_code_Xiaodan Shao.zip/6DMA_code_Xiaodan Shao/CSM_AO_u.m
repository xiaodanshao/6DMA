
function [initial_val,value_per_iter,q_opt,u_opt] = CSM_AO_u(q,u,N,B,transmit_power,noise_power,lammda,r_local,iter,zk_tag,region_size)
%% generate initial position and rotation
% zk_tag = load("zk.mat");
% zk_tag = zk_tag.zk;
% zk = get_zk(zk_tag);


%% parameters set up

value_per_iter = zeros(1,iter);

check_feasible_u(q,u,N,B,lammda,r_local,region_size)

%% AO main funcation
% get_object_value(q_initial,u,zk_tag,N,B,lammda)
tau_init = 1;
tau_min = 0.0001;
K_trial =  size(zk_tag,2);

R = zeros(3,3,B);
r = zeros(3,N,B);

for i = 1:K_trial
    num_user = size(zk_tag{i},1);
    W_s{i} = zeros(num_user,num_user,B);
    % W{s,i} = zeros(num_user,num_user,B);
    W_sum=zeros(num_user,num_user);
    for b = 1:B
        q_b = q(3*(b - 1) + 1 : 3*b);
        u_b = u(3*(b - 1) + 1 : 3*b);
        R(:,:,b) = get_rotation_matrix(u_b);
        r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
        
        vv = zeros(num_user,1);
        A_bb = zeros(N,num_user);
        for user_idx = 1:num_user
            k_m = get_k_vector(zk_tag{i}(user_idx,1),zk_tag{i}(user_idx,2),zk_tag{i}(user_idx,3));
            vv(user_idx) = get_attenuation_factor(zk_tag{i}(user_idx,1:3),lammda);
            % a(:,b) = get_steering_vector(k_m,r(:,:,b),lammda);
            a_b = exp(-1i*2*pi/lammda*(k_m'* r(:,:,b))).';
            % g = get_antenna_pattern(k_m,R(:,:,b));        
            local_location = -R(:,:,b) * k_m;
            local_location = (local_location)/vecnorm(local_location);
            theta_prime = acos(local_location(3));
            phi_prime = acos(local_location(1)/(sqrt(local_location(1)^2+local_location(2)^2)));
            a_H_E = -12 * ((phi_prime * 2.769) ^ 2 + ((theta_prime - pi/2 ) * 2.769) ^ 2 );
            a_gpu = 10^((a_H_E)/10);
            g_gpu = 7.943 * sqrt(a_gpu);
            % g_gpu = 7.943 * sqrt(max(10^(-10),a_gpu));
            G_b_k=a_b*g_gpu ;
            A_bb(:,user_idx)=G_b_k; 
        end
            A_b=A_bb.';
            sigm=diag(vv);
            P=transmit_power*ones(num_user,1);
            Lam=diag(P);
            W=Lam^(0.5)*sigm'*A_b;
            W_sum=W_sum+W*W';
            % W*W'
            W_s{i}(:,:,b) = W*W';
    end
end

    
initial_val = get_object_value_from_W(noise_power,zk_tag,W_s)
% get_object_value(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local)

for t = 1:iter


    


    for b = 1:B
        for i = 1:5
            u_b = u(3*(b - 1) + 1 : 3*b);
            [f_d,d_u,Fx] = find_feasible_direction_u(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local,b,W_s);
            if(isempty(f_d))
                break;
            end
            tau = find_stepsize_u(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local,region_size,d_u,f_d,Fx,b,W_s);
            if(tau == 0)
                break;
            end
            u(3*(b - 1) + 1 : 3*b) =  u_b + tau * f_d;
            W_s = updata_W(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W_s);
            % check_feasible_u(q,u,N,B,lammda,r_local)
        end
        
    end

    for b = 1:B
        
        for i = 1:1

            q_b = q(3*(b - 1) + 1 : 3*b);
            [f_d,d_q,Fx] = find_feasible_direction_q(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local,region_size,b,W_s);

            if(isempty(f_d))
                break;
            end

            tau = find_stepsize_q(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local,d_q,f_d,Fx,b,W_s);
            if(tau == 0)
                break;
            end
            q(3*(b - 1) + 1 : 3*b) =  q_b + tau * f_d;
            W_s = updata_W(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W_s);
            % check_feasible_u(q,u,N,B,lammda,r_local)
        end
        
    end


    value_per_iter(t) =   get_object_value_from_W(noise_power,zk_tag,W_s);
    value_per_iter(t)
    % check_feasible_u(q,u,N,B,lammda,r_local)
    % value_per_iter(t) =   get_object_value_from_W_real(noise_power,zk_tag,W_s);
    % value_per_iter(t)
    % get_object_value_real(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local)
    % value_per_iter(t) = get_object_value_real(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local);
    % disp(value_per_iter(t));
    % disp_units(q',u',B,r_local,zk_tag);
    % axis equal
    % close all
end
q_opt = q;
u_opt = u;

end

function W_new = updata_W(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W)
K_trial = size(zk_tag,2);
q_b = q(3*(b - 1) + 1 : 3*b);
u_b = u(3*(b - 1) + 1 : 3*b);
R_b = get_rotation_matrix(u_b);
r_b = get_global_antenna_location(r_local,R_b,q_b);
num_total_user = zeros(K_trial,1);
for j = 1 : K_trial
    num_total_user(j) = size(zk_tag{j},1);
end

for i=1:K_trial
    if(isempty(zk_tag{i}))
        continue;
    end
    zk = zk_tag{i};
    num_user = size(zk,1);
    vv = zeros(num_user,1);
    A_bb = zeros(N,num_user);
    for user_idx = 1:num_user
        k_m = get_k_vector(zk(user_idx,1),zk(user_idx,2),zk(user_idx,3));
        vv(user_idx) = get_attenuation_factor(zk(user_idx,1:3),lammda);
        % a(:,b) = get_steering_vector(k_m,r(:,:,b),lammda);
        a_b = exp(-1i*2*pi/lammda*(k_m'* r_b)).';
        % g = get_antenna_pattern(k_m,R(:,:,b));        
        local_location = -R_b * k_m;
        local_location = (local_location)/vecnorm(local_location);
        theta_prime = acos(local_location(3));
        phi_prime = acos(local_location(1)/(sqrt(local_location(1)^2+local_location(2)^2)));
        a_H_E = -12 * ((phi_prime * 2.769) ^ 2 + ((theta_prime - pi/2 ) * 2.769) ^ 2 );
        a_gpu = 10^((a_H_E)/10);
        g_gpu = 7.943 * sqrt(a_gpu);
        % g_gpu = 7.943 * sqrt(max(10^(-10),a_gpu));
        G_b_k=a_b*g_gpu ;
        A_bb(:,user_idx)=G_b_k; 
    end
    A_b=A_bb.';
    sigm=diag(vv);
    Lam=diag(transmit_power*ones(num_user,1));
    W_tmp=Lam^(0.5)*sigm'*A_b;
    W{i}(:,:,b) = W_tmp * W_tmp';
end
W_new = W;

end






