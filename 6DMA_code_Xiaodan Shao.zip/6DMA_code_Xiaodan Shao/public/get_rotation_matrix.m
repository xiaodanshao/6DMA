function R_b = get_rotation_matrix(u_b)
alpha = u_b(1);
beta = u_b(2);
gamma = u_b(3);
R_alpha = [cos(alpha),  0,          -sin(alpha);
            0,          1,          0;
            sin(alpha), 0,          cos(alpha)];

R_beta  = [1,           0 ,         0;
           0,           cos(beta),  sin(beta);
           0,           -sin(beta), cos(beta)];

R_gamma = [cos(gamma),  sin(gamma), 0;
           -sin(gamma), cos(gamma), 0;
            0,          0,          1];

R_b = R_beta * R_alpha * R_gamma;

end