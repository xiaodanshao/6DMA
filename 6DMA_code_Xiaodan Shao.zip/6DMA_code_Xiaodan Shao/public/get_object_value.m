% 
function E_C = get_object_value(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local)
K_trial = size(zk_tag,2);
R = zeros(3,3,B);
r = zeros(3,N,B);
for b = 1:B
    q_b = q(3*(b - 1) + 1 : 3*b);
    u_b = u(3*(b - 1) + 1 : 3*b);
    R(:,:,b) = get_rotation_matrix(u_b);
    r(:,:,b) = get_global_antenna_location(r_local,R(:,:,b),q_b);
end
E_C = 0;
num_total_user = zeros(K_trial,1);
for j = 1 : K_trial
    num_total_user(j) = size(zk_tag{j},1);
end
% tic

E_C_s = zeros(K_trial,1);

for i=1:K_trial
    E_C_s(i) = get_capacity(N,R,r,transmit_power,noise_power,zk_tag{i},lammda,B); 
end

E_C = E_C + sum(E_C_s,"all")/K_trial;

E_C = real(E_C);


    function C_q_u_zk = get_capacity(N,R,r,transmit_power,noise_power,zk,lammda,B)
    num_user = size(zk,1);
    % a = gpuArray(zeros(N,B));
    h = zeros(num_user,N*B);
    for user_idx = 1:num_user
        k_m = get_k_vector(zk(user_idx,1),zk(user_idx,2),zk(user_idx,3));
        v = get_attenuation_factor(zk(user_idx,1:3),lammda);
        for n = 1:B
    
            % a(:,b) = get_steering_vector(k_m,r(:,:,b),lammda);
            a_b = exp(-1i*2*pi/lammda*(k_m'* r(:,:,n))).';
    
            % g = get_antenna_pattern(k_m,R(:,:,b));        
            local_location = -R(:,:,n) * k_m;
            local_location = (local_location)/vecnorm(local_location);
            theta_prime = acos(local_location(3));
            phi_prime = acos(local_location(1)/(sqrt(local_location(1)^2+local_location(2)^2)));
            a_H_E = -12 * ((phi_prime * 2.769) ^ 2 + ((theta_prime - pi/2 ) * 2.769) ^ 2 );
            a_gpu = 10^((a_H_E)/10);
            % g_gpu = 7.943 * sqrt(max(10^(-10),a_gpu));
            g_gpu = 7.943 * sqrt(a_gpu);
       
            h(user_idx,N*(n - 1) + 1 : N*n) = g_gpu * v * a_b.';
        end
    end
    C_q_u_zk = real(log2(det(diag(ones(1,N*B)) + ...
        transmit_power * (h' * h) ./noise_power)));
    end
end