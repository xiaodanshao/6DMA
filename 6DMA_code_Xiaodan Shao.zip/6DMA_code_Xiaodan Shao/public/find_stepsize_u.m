% d_k: gradient direction
% f_d: feasible direction
function alpha = find_stepsize_u(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local,region_size,d_k_u,f_d_u,F_x,b,W)
sigma = 10^(-2);
beta = 0.5;
% s = 0.1 + 0.9 * rand();
s = 1;
% get_object_value(q,u,zk,zk_tag,N,B,lammda);
u_b = u(3*(b - 1) + 1 : 3*b);
m = 0;
while(1)
    alpha = beta^m * s;
    u(3*(b - 1) + 1 : 3*b) = u_b + alpha * f_d_u;
    if((get_object_value_rec(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W) - ...
            F_x >= sigma * beta^m * s * d_k_u' * f_d_u) &&...
            check_feasible_u(q,u,N,B,lammda,r_local))
        break;
    end
    if(m>10)
        alpha = 0;
        break;
    end
    m = m+1;
end

end