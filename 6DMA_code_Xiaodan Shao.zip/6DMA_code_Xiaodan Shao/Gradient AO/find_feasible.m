function [q_feasible,u_feasible] = find_feasible(q,u,N,B,lammda)
% u = zeros(3*N*B,1);
% for b = 1:B
%     u(3*(b - 1) + 1 : 3*b) = [-asin(R_initial(1,3,b));
%                                 atan2(R_initial(2,3,b),R_initial(3,3,b));
%                                 atan2(R_initial(1,2,b),R_initial(1,1,b))];
% end
for b = 1:B
    if(check_feasible_u(q,u,N,B,lammda))
        continue;
    end
    tau_init = 10;
    tau_min = 2 ^ (-4);
    tau = tau_min;
    % q_b = q(3*(b - 1) + 1 : 3*b);
    % u_b = u(3*(b - 1) + 1 : 3*b);
    while(penalty(q,u,B,lammda,b) > 1)
        q_b = q(3*(b - 1) + 1 : 3*b);
        u_b = u(3*(b - 1) + 1 : 3*b);
        [d_q,~] = get_d_q_penalty(q,u,B,lammda,b);
        [d_u,E_C] = get_d_u_penalty(q,u,B,lammda,b);
        q(3*(b - 1) + 1 : 3*b) = q_b - tau * d_q;
        u(3*(b - 1) + 1 : 3*b) = u_b - tau * d_u;
        
        u = mod(u,2*pi);

        while(penalty(q,u,B,lammda,b) > E_C)
            tau = tau * 0.5;
            q(3*(b - 1) + 1 : 3*b) = q_b - tau * d_q;
            u(3*(b - 1) + 1 : 3*b) = u_b - tau * d_u;
        end

        
    end
end
% for i = 1:B
%     u_b = u(3*(b - 1) + 1 : 3*i);
%     R(:,:,i) = get_rotation_matrix(u_b);
% end
q_feasible = q;
u_feasible = u;
end

function res = penalty(q,u,B,lammda,b)
R = zeros(3,3,B);
for i = 1:B
    u_b = u(3*(i - 1) + 1 : 3*i);
    R(:,:,i) = get_rotation_matrix(u_b);
end

penalty_factor = 10;

penalty_overlap = 0;
penalty_blockage = 0;

q_b = q(3*(b-1)+1:3*b,1);
norm_b = R(:,:,b)' * [1;0;0];
for j = 1:B
    if (b==j)
        continue;
    end
    q_j = q(3*(j-1)+1:3*j,1);
    if(vecnorm(q_b-q_j) - 2 * lammda < 0)
        penalty_overlap = penalty_overlap + (exp(2 * lammda - vecnorm(q_b-q_j))-1);
    end


    if(norm_b' * (q_j - q_b) > 0)
        penalty_blockage = penalty_blockage + (exp(norm_b' * (q_j - q_b))-1);
    end
end
penalty_region = exp(max(0,vecnorm(q_b)-1.8)) - 1;


res = penalty_factor * (penalty_overlap + penalty_blockage + penalty_region);

end

function [d_q,E_C] = get_d_q_penalty(q,u,B,lammda,b)
delta = 2^(-16);
d_q = zeros(3,1);
E_C = penalty(q,u,B,lammda,b);
for i = 1:3
    delta_q = zeros(3,1);
    delta_q(i) = delta;
    q_b_next = q(3*(b - 1) + 1 : 3*b) + delta_q;
    q_next = q;
    q_next(3*(b - 1) + 1 : 3*b) = q_b_next;
    d_q(i) = (penalty(q_next,u,B,lammda,b) - E_C)/delta;
end
d_q = d_q/vecnorm(d_q);
end

function [d_u,E_C] = get_d_u_penalty(q,u,B,lammda,b)
delta = 2^(-16);
d_u = zeros(3,1);
E_C = penalty(q,u,B,lammda,b);
for i = 1:3
    delta_u = zeros(3,1);
    delta_u(i) = delta;
    u_b_next = u(3*(b - 1) + 1 : 3*b) + delta_u;
    u_next = u;
    u_next(3*(b - 1) + 1 : 3*b) = u_b_next;
    d_u(i) = (penalty(q,u_next,B,lammda,b) - E_C)/delta;
end
d_u = d_u/vecnorm(d_u);
end