function [d_k_u,d_u,Fx] = find_feasible_direction_u(q,u,transmit_power,noise_power,zk_tag,N,B,lammda,r_local,b,W)

[d_u,Fx] = get_d_u(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W);
% d_k_u = d_u;
q_b = q(3*(b - 1) + 1 : 3*b);

% object function
% c = d_u(2:3);
c = -d_u';



% % relaxed constraint (45B)
u_b = u(3*(b - 1) + 1 : 3*b);
R_b = get_rotation_matrix(u_b);
A_1 = zeros((B-1),3);
b_1 = zeros((B-1),1);
j = 1;
for i = 1:B
    if(i == b)
        continue;
    end
    q_j = q(3*(i - 1) + 1 : 3*i);
    coef1 = [1 0 0] * R_b;
    coef2 = q_j - q_b;
    aa = coef1(1);
    bb = coef1(2);
    cc = coef1(3);
    dd = coef2(1);
    ee = coef2(2);
    ff = coef2(3);

    A_1(j,:) = -[cc*ee - bb*ff,aa*ff - cc*dd,bb*dd - aa*ee];
    b_1(j,1) = -(aa*dd + bb*ee + cc*ff);

    % u_j = u(3*(i - 1) + 1 : 3*i);
    % R_j = get_rotation_matrix(u_j);
    % coef1 = [1 0 0] * R_j';
    % coef2 = q_b - q_j;
    % aa = coef1(1);
    % bb = coef1(2);
    % cc = coef1(3);
    % dd = coef2(1);
    % ee = coef2(2);
    % ff = coef2(3);
    % A_1((B-1) + j,:) = [cc*ee - bb*ff,aa*ff - cc*dd,bb*dd - aa*ee];
    % b_1((B-1) + j,1) = -(aa*dd + bb*ee + cc*ff);

    j = j+1;
end

% constraint (42B)
lb = -pi/12 * ones(3,1);
ub = pi/12 * ones(3,1);

% constraint (50c)
A_2 = zeros(1,3);
b_2 = zeros(1,1);
coef1 = [1 0 0] * R_b;
coef2 = - q_b;
aa = coef1(1);
bb = coef1(2);
cc = coef1(3);
dd = coef2(1);
ee = coef2(2);
ff = coef2(3);

A_2(1,:) = -[cc*ee - bb*ff,aa*ff - cc*dd,bb*dd - aa*ee];
b_2(1,1) = -(aa*dd + bb*ee + cc*ff);


while(1)
    
    options = optimoptions('linprog', 'Display', 'off');
    [d_k_u,~] = linprog(c,[A_1;A_2],[b_1;b_2],[],[],lb,ub,options);
    
    if(isempty(d_k_u))
        d_k_u = [0;0;0];
        break;
    end
       
    % else
    %     % d_k_u = d_k_u - u_b;
    %     d_u' * d_k_u
    % end
    u(3*(b - 1) + 1 : 3*b) = u_b + d_k_u;
    if(check_feasible_u(q,u,N,B,lammda,r_local))
        break;
    else
        lb = lb/2;
        ub = lb/2;
    end
end
end

function [d_u,E_C] = get_d_u(q,u,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W)
delta = 2^(-16);
d_u = zeros(3,1);
E_C = get_object_value_from_W(noise_power,zk_tag,W);
for i = 1:3
    delta_u = zeros(3,1);
    delta_u(i) = delta;
    u_b_next = u(3*(b - 1) + 1 : 3*b) + delta_u;
    u_next = u;
    u_next(3*(b - 1) + 1 : 3*b) = u_b_next;
    d_u(i) = (get_object_value_rec(q,u_next,transmit_power,noise_power,zk_tag,N,lammda,r_local,b,W) - E_C)/delta;
end

end