function zk = get_zk(zk_tag)

for i = 1:size(zk_tag,2)
    zk_i = zk_tag{i};
    zk_i = zk_i(:,1:3);
    zk{i} = zk_i;
end

end