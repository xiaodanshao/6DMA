function num_overlap = region_constraint(q,region_size)

check_1 = abs(q)>region_size;
num_overlap = sum(check_1 ~=0);

end
